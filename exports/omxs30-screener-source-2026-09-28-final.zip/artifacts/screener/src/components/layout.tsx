import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { LineChart, Sunrise, LayoutDashboard, History, FileDown, Activity, Swords, CalendarDays, LogOut, ArrowRight } from "lucide-react";
import { useAuthContext } from "../lib/auth-context";

export function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuthContext();

  const navItems = [
    { href: "/", label: "Idag", icon: Sunrise },
    { href: "/sessions/today", label: "Dagens session →", icon: ArrowRight },
    { href: "/survival", label: "Challenge Tracker", icon: Swords },
    { href: "/sessions", label: "Sessions", icon: History },
    { href: "/dashboard", label: "Statistik", icon: LayoutDashboard },
    { href: "/candidates", label: "Candidates", icon: Activity },
    { href: "/import", label: "Import Data", icon: FileDown },
    { href: "/earnings", label: "Rapporter", icon: CalendarDays },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Sidebar */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-border bg-card flex flex-col">
        <div className="h-16 flex items-center px-5 border-b border-border gap-3">
          <LineChart className="w-5 h-5 shrink-0 text-primary" />
          <div className="min-w-0">
            <h1 className="font-bold text-sm tracking-tight leading-tight">AG Investment Capital</h1>
            <p className="text-[10px] text-muted-foreground tracking-wide uppercase">Private Dashboard</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive =
              location === item.href ||
              (item.href !== "/" &&
                location.startsWith(item.href) &&
                // /sessions must not activate when location is /sessions/today (separate nav item)
                !(item.href === "/sessions" && location.startsWith("/sessions/today")));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-colors ${
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                <item.icon className={`w-4 h-4 mr-3 ${isActive ? "text-primary-foreground" : "text-muted-foreground"}`} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border space-y-3">
          {user && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                {user.profileImageUrl ? (
                  <img src={user.profileImageUrl} alt="" className="w-6 h-6 rounded-full shrink-0" />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-primary/20 shrink-0 flex items-center justify-center text-[10px] font-bold text-primary">
                    {(user.firstName?.[0] ?? user.email?.[0] ?? "?").toUpperCase()}
                  </div>
                )}
                <span className="text-xs text-muted-foreground truncate">
                  {user.firstName ?? user.email ?? "User"}
                </span>
              </div>
              <button
                onClick={logout}
                title="Log out"
                className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          <div className="text-xs text-muted-foreground font-mono">
            System: ONLINE
            <br />
            Market: NASDAQ STO
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-[100dvh] overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
